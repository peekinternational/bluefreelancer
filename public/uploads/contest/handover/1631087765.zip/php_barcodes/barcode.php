<html>
<head>
<style>
p.inline {display: inline-block;}
span { font-size: 17px; font-family:Arial; text-transform:uppercase;}

</style>
<style type="text/css" media="print">
    @page 
    {
        size: auto;   /* auto is the initial value */
        margin: 0mm;  /* this affects the margin in the printer settings */

    }
</style>
</head>
<body onload="window.print();">
	<div style="margin-left: 5%">
		<?php
		include 'barcode128.php';
		$product = $_POST['product'];
		$branch = $_POST['branch'];
		$quantity = $_POST['quantity'];
		$product_id = $_POST['product_id'];
		$rate = $_POST['rate'];

		for($i=1;$i<=$_POST['print_qty'];$i++){
			echo "<center><p class='inline'><span><font family=arial size=30>$product_id</b></span><br><span ><b>$branch</b></span><br><span ><b>$quantity</b></span><br><span ><b>".$rate." </b><br><span><b>$product</b></span></p>&nbsp&nbsp&nbsp";
		}

		?>
	</div>
</body>
</html>